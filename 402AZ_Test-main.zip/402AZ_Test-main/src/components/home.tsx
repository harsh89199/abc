import React from "react";

export default function Home() {

    return (
        <>
            <section className="hero is-large is-info">
                <div className="hero-body">
                    <p className="title">
                        Home Page
                    </p>
                    <p className="subtitle">
                        Large subtitle
                    </p>
                </div>
            </section>
        </>
    );
}